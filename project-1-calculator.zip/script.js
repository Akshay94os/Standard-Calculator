const display = document.getElementById('display');

function appendChar(char) {
  if (display.value === '0' && char !== '.') {
    display.value = char;
  } else {
    display.value += char;
  }
}

function clearDisplay() {
  display.value = '';
}

function calculate() {
  try {
    display.value = eval(display.value) || '';
  } catch (e) {
    display.value = 'Error';
    setTimeout(clearDisplay, 1500);
  }
}